PROJET : DÉCOUVERTE DU SÉNÉGAL
Technologies : HTML5, CSS3 et Bootstrap 5.

Pour ouvrir :
1. Décompresser le dossier.
2. Ouvrir index.html dans un navigateur ou avec Visual Studio Code.
3. Garder le dossier images à côté de index.html : il contient les photos utilisées.

Bootstrap est chargé par CDN ; une connexion Internet est nécessaire pour le CSS et le menu responsive.
Les photographies sont extraites de l'image de référence fournie pour reproduire sa présentation.
Le formulaire est une démonstration locale et n'envoie pas de message.
